﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2Assignment
{
    class MainOfStudent2
    {
        static void Main()
        {
            int[] marks = new int[5];
            Console.WriteLine("Enter 5 marks");
            for (int i = 0; i < 5; i++)
            {
                marks[i] = int.Parse(Console.ReadLine());
            }
            Student2 s1 = new Student2(101, "Nagashree", 1, 2, "TCE");
            s1.displayDetails();
            s1.displayResult(marks);
            Console.ReadKey();


        }
    }
}
