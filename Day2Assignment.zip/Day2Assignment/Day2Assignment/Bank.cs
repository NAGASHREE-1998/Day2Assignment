﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2Assignment
{
    class BankException : Exception
    {
        public BankException(string msg) : base(msg) { }
    }
    class Bank
    {

        public string name;
        public long accountNumber;
        public string accountType;
        public double balance;


        public Bank()
        {
            Console.WriteLine("Enter name of depositor");
            name = Console.ReadLine();
            Console.WriteLine("Enter Account number");
            accountNumber = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter Account type");
            accountType = Console.ReadLine();

            Console.WriteLine("Enter balance");
            balance = double.Parse(Console.ReadLine());
        }

        public void Deposit(double newAmmount)
        {
            balance = balance + newAmmount;
        }

        public void Withdraw(double amount)
        {
            try
            {
                if (balance - amount < 0)
                    throw new BankException("In sufficient balance");
                else
                    balance = balance - amount;
            }
            catch (BankException b)
            {
                Console.WriteLine(b.Message);
            }
        }

        public void DisplayBalance()
        {
            Console.WriteLine(name + "/t" + balance);
        }
    }

    class Test_BankAccount
    {
        static void Main()
        {
            Bank bank = new Bank();
            bank.Deposit(60000);
            bank.Withdraw(15000);
            bank.DisplayBalance();
            Console.ReadKey();
        }
    }
}


