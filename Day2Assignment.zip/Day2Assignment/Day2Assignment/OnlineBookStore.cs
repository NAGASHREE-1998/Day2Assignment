﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Day2Assignment
{
    class OnlineBookStore
    {
        public int bookno;
        public string bookName;
        public string bookTitle;
        public string bookAuthor;
        public int bookQuantity;
        public double bookPrice;
        public void Details()
        {
            Console.WriteLine("BookNumber: " + bookno);
            Console.WriteLine("Bookname: " + bookName);
            Console.WriteLine("Book Title: " + bookTitle);
            Console.WriteLine("BookAuthor: " + bookAuthor);
            Console.WriteLine("BookQuantity: " + bookQuantity);
            Console.WriteLine("Book Price: " + bookPrice);
        }

        public double ammountPayable(int qty, double price)
        {
            double totalprice = qty * price;
            return totalprice;

        }
    }

    class Test_Book
    {
        static void Main()
        {
            OnlineBookStore bs = new OnlineBookStore();
            bs.bookno = 1001;
            bs.bookName = "Five Point Someone";
            bs.bookTitle = "IIT";
            bs.bookAuthor = "Chetan Bhagat";
            bs.bookQuantity = 15;
            bs.bookPrice = 500;
            bs.Details();
            Console.WriteLine("Total price to be paid is " + bs.ammountPayable(bs.bookQuantity, bs.bookPrice));
            Console.ReadKey();
        }
    }
}

    
